# Changelog

Download the latest release from the [releases page}(https://github.com/winkelband/pandoc-latex-g-brief2/releases/).

## [1.0.0] – 2020-08-12

* Initial release.
