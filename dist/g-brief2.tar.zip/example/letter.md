---
author: Erika Musterfrau
name:
  line1: \textbf{Erika Musterfrau}
  line2: Süßwaren & Salziges
phone:
  line1: "+49 / 0 07 / 98 76 54 30"
internet:
  line1: mail@example.org
  line2: www.example.org
banking:
  line1: DEUTDEFF123
  line2: DE12 3456 7891 0111 2131 41
  line3: Musterbank Musterstadt

return-address-envelope:
  - Erika Musterfrau
  - Ottostraße 13a
  - 12345 Berlin
return-address-footer:
  line1: Erika Musterfrau
  line2: Ottostraße 13a // App. 100
  line3: 12345 Berlin

postalnote: Top Secret
address:
  - Alex Mustermensch
  - Musterhausener Str. 11
  - 54321 Konz

recipient-refsign:
  value: am
recipient-letter:
  value: 01.01.1970
sender-refsign:
  value: em

subject: Mustersüßigkeiten
title: Brief an Alex Mustermensch

opening: Hallo Alex Mustermensch,
closing: Mit süßen Grüßen

enclosures:
  - Produktkatalog
  - Lollipop XXL

trendlines: false
envelopemarks: false
foldmarks: true
punchmark: false

lang: de-DE
...

ich danke Ihnen innig für Ihre Anfrage.

[//]: # :::{lang=en}

Lollipop cake soufflé sesame snaps donut dessert fruitcake.
Icing pudding gingerbread tootsie roll caramels gingerbread cheesecake brownie powder.
Croissant chupa chups tart cheesecake cupcake dessert biscuit pudding.
Cheesecake tart gummies topping pudding fruitcake jelly-o apple pie.
Toffee brownie pudding gingerbread cake donut gummi bears.
Sweet lollipop cupcake toffee lollipop.

[//]: # :::

Werfen Sie einen Blick in meinen aktuellen Produktkatalog –
ich sende Ihnen gerne Kostproben zu.
